#include "Brick.h"

int Brick::getBreakCounter() {
	return Brick::_breakCounter;
}

void Brick::BreakBrick() {
	if (Brick::_breakCounter > 0) {
		Brick::_breakCounter--;
	}
	if(Brick::_breakCounter == 0) {
		_leftX = 0;
		_rightX = 0;
		_topY = 0;
		_bottomY = 0;
	}
	return;
}

float Brick::getBottomY() {
	return Brick::_bottomY;
}

float Brick::getLeftX() {
	return Brick::_leftX;
}

float Brick::getTopY() {
	return Brick::_topY;
}

float Brick::getRightX() {
	return Brick::_rightX;
}

void Brick::setLeftX(float newLeftX) {
	Brick::_leftX = newLeftX;
	return;
}

void Brick::setTopY(float newTopY) {
	Brick::_topY = newTopY;
	return;
}

void Brick::setRightX(float newRightX) {
	Brick::_rightX = newRightX;
	return;
}

void Brick::setBottomY(float newBottomY) {
	Brick::_bottomY = newBottomY;
	return;
}