#pragma once


class Brick {
public:
	int getBreakCounter();
	void BreakBrick();
	float getBottomY();
	float getLeftX();
	float getTopY();
	float getRightX();
	void setLeftX(float newLeftX);
	void setTopY(float newTopY);
	void setRightX(float newRightX);
	void setBottomY(float newBottomY);
private:
	int _breakCounter = 3;
	float _bottomY;
	float _leftX;
	float _topY;
	float _rightX;
};