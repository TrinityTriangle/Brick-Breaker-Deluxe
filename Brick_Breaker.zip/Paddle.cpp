#include "Paddle.h"

Paddle::Paddle(float leftX, float topY) {
	_leftX = leftX;
	_topY = topY;
}

float Paddle::getBottomY() {
	return Paddle::_bottomY;
}

float Paddle::getLeftX() {
	return Paddle::_leftX;
}

float Paddle::getTopY() {
	return Paddle::_topY;
}

float Paddle::getRightX() {
	return Paddle::_rightX;
}

void Paddle::setLeftX(float newLeftX) {
	Paddle::_leftX = newLeftX;
	return;
}

void Paddle::setTopY(float newTopY) {
	Paddle::_topY = newTopY;
	return;
}

void Paddle::setRightX(float newRightX) {
	Paddle::_rightX = newRightX;
	return;
}

void Paddle::setBottomY(float newBottomY) {
	Paddle::_bottomY = newBottomY;
	return;
}

float Paddle::MovePaddle(float velocity) {
	Paddle::_leftX += velocity;
	Paddle::_rightX += velocity;
	return getLeftX();
}