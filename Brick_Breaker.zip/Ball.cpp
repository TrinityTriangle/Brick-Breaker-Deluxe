#include "Ball.h"

Ball::Ball(float radius, float xPos, float yPos, float xVel, float yVel) {
	_radius = radius;
	_xPos = xPos;
	_yPos = yPos;
	_xVel = xVel;
	_yVel = yVel;
}

void Ball::setRadius(float radius) {
	_radius = radius;
	return;
}

void Ball::setXPos(float xPos) {
	_xPos = xPos;
	return;
}

void Ball::setYPos(float yPos) {
	_yPos = yPos;
	return;
}

void Ball::setXVel(float xVel) {
	_xVel = xVel;
	return;
}

void Ball::setYVel(float yVel) {
	_yVel = yVel;
	return;
}

float Ball::getRadius() {
	return _radius;
}

float Ball::getXPos() {
	return _xPos;
}

float Ball::getYPos() {
	return _yPos;
}

float Ball::getXVel() {
	return _xVel;
}

float Ball::getYVel() {
	return _yVel;
}

void Ball::MoveBall() {
	_xPos += _xVel;
	_yPos += _yVel;
	return;
}

void Ball::xBounce() {
	_xVel *= -1;
	return;
}

void Ball::yBounce() {
	_yVel *= -1;
	return;
}