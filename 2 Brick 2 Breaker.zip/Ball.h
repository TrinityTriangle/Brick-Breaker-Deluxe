#pragma once

class Ball{
public:
	Ball();
	Ball(float radius, float xPos, float yPos, float xVel, float yVel);
	void setRadius(float radius);
	void setXPos(float xPos);
	void setYPos(float yPos);
	void setXVel(float xVel);
	void setYVel(float yVel);
	float getRadius();
	float getXPos();
	float getYPos();
	float getXVel();
	float getYVel();
	void MoveBall();
	void xBounce();
	void yBounce();
private:
	float _radius;
	float _xPos;
	float _yPos;
	float _xVel; // velocity
	float _yVel;
};