#pragma once

class Paddle {
public:
	Paddle();
	Paddle(float leftX, float topY);
	float getBottomY();
	float getLeftX();
	float getTopY();
	float getRightX();
	void setLeftX(float newLeftX);
	void setTopY(float newTopY);
	void setRightX(float newRightX);
	void setBottomY(float newBottomY);
	float MovePaddle(float velocity);
private:
	float _bottomY;
	float _leftX;
	float _topY;
	float _rightX;
};