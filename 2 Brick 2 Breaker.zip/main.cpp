/*

~*BRICK BREAKER*~

*/







#include <SFML/Graphics.hpp>

#include "Brick.h"
#include "Paddle.h"
#include "Ball.h"
#include <random>
#include <cmath>
#include <iostream>
//#include "RoundedRectangle.h"

using namespace sf;

const float WINDOW_WIDTH = 800;
const float WINDOW_HEIGHT = 600;
const int NUM_ROWS = 9;
const int NUM_COLS = 10;
const float BRICK_WIDTH = WINDOW_WIDTH/NUM_ROWS;
const float BRICK_HEIGHT = WINDOW_HEIGHT / (2.5*NUM_ROWS); // bricks occupy top two-fifths of the screen
const float PADDLE_WIDTH = 1.5*BRICK_WIDTH;
const float PADDLE_HEIGHT=BRICK_HEIGHT;
const float PADDLE_TOP_Y = WINDOW_HEIGHT - 2 * PADDLE_HEIGHT;
const float PADDLE_LEFT_X_INITIAL = (WINDOW_WIDTH - PADDLE_WIDTH) / 2;
const float PADDLE_SPEED = 10;
const float BALL_RADIUS = 16;
float ballXPos = WINDOW_WIDTH / 2;
float ballYPos = WINDOW_HEIGHT / 2;
const float BALL_SPEED = 1;
const float BALL_X_SPEED = 0.5;
const float BALL_Y_SPEED = sqrt(BALL_SPEED*BALL_SPEED - BALL_X_SPEED*BALL_X_SPEED);
const int FRAME_TIME = 30; //number of milliseconds per frame

int i = 0;
int j = 0;


RectangleShape DrawBrick(Brick brick);
RectangleShape DrawPaddle(Paddle paddle);
CircleShape DrawBall(Ball ball);

void CheckIfBrokenX(Ball ball, Brick wall[NUM_ROWS][NUM_COLS]);

/*
void xCollisionEvent();
void yCollisionEvent();

void xCollisionBrick(brick brokenBrick);
void yCollisionBrick(brick brokenBrick);
*/

int main() {
	RenderWindow window(VideoMode(WINDOW_WIDTH, WINDOW_HEIGHT), "Brick Breaker");
	Brick wall[NUM_ROWS][NUM_COLS]; // generates an array of bricks
	for (i = 0; i < NUM_ROWS; ++i) {
		for (j = 0; j < NUM_COLS; ++j){ 
			wall[i][j].setLeftX(j*BRICK_WIDTH); // sets boundary values for brick borders
			wall[i][j].setTopY(i*BRICK_HEIGHT); // we need this to do collisions
			wall[i][j].setRightX((j + 1)*BRICK_WIDTH);
			wall[i][j].setBottomY((i + 1)*BRICK_HEIGHT);
		}
	}
	Paddle paddle(PADDLE_LEFT_X_INITIAL, PADDLE_TOP_Y);
	paddle.setBottomY(PADDLE_TOP_Y + PADDLE_HEIGHT);
	
	Ball ball(BALL_RADIUS, ballXPos, ballYPos, BALL_X_SPEED, BALL_Y_SPEED);

	// run the program as long as the window is open
	while (window.isOpen())
	{
		// check all the window's events that were triggered since the last iteration of the loop
		Event event;
		while (window.pollEvent(event))
		{
			// "close requested" event: we close the window
			if (event.type == Event::Closed)
				window.close();
			else if (event.type == Event::KeyPressed) {
				if (event.key.code == Keyboard::Left && paddle.getLeftX()>0) { // keeps paddle from going off the left edge of the screen
					paddle.setLeftX(paddle.MovePaddle(-1 * PADDLE_SPEED)); // negative velocity
					paddle.setRightX(paddle.getLeftX() + PADDLE_WIDTH);
				}
				else if (event.key.code == Keyboard::Right && paddle.getRightX()<WINDOW_WIDTH) { // keeps paddle from going off the right edge of the screen
					paddle.setLeftX(paddle.MovePaddle(PADDLE_SPEED));
					paddle.setRightX(paddle.getLeftX() + PADDLE_WIDTH);
				}
			}
		}
		// xBounce statements
		if (ball.getXPos() +2*ball.getRadius() >= WINDOW_WIDTH || ball.getXPos() <= 0) { // bounces ball off side walls
			ball.xBounce();
		}
		else if ((fabs(ball.getXPos()+2*ball.getRadius()-paddle.getLeftX())<1 //bounces ball off of side of paddle
			|| fabs(ball.getXPos()-paddle.getRightX())<1)
			&& ball.getYPos()+2*ball.getRadius()>paddle.getTopY()
			&& ball.getYPos() < paddle.getBottomY() ) {
			ball.xBounce();
		}
		else {
			CheckIfBrokenX(ball, wall);
		}
		// yBounce statements
		if (fabs(ball.getYPos() + 2*ball.getRadius() - PADDLE_TOP_Y) < 1 // bounces ball off of top of paddle
			&& ball.getXPos()+2*ball.getRadius() > paddle.getLeftX()
			&& ball.getXPos() < paddle.getRightX()) {
			ball.yBounce();
		}
		else if (ball.getYPos() <= 0) { // bounces ball off of top of screen
			ball.yBounce();
		}
		else if (fabs(ball.getYPos() + 2 * ball.getRadius() - WINDOW_HEIGHT) < 1) {
			break;
		}
		else {
			for (i = 0; i < NUM_ROWS; ++i) {
				for (j = 0; j < NUM_COLS; ++j) {
					if ((fabs(ball.getYPos() - wall[i][j].getBottomY()) < 1 // bounces ball off of top or bottom of brick
						|| fabs(ball.getYPos() + 2 * ball.getRadius() - wall[i][j].getTopY()) < 1)
						&& ball.getXPos() + 2 * ball.getRadius() > wall[i][j].getLeftX()
						&& ball.getXPos() < wall[i][j].getRightX()) {
						ball.yBounce();
						wall[i][j].BreakBrick();
						break;
					}
				}
			}
		}

		ball.MoveBall();
		

		// clear the window with black color
		window.clear(Color::White);

		// draw everything here...
		for (i = 0; i < NUM_ROWS; ++i) {
			for (j = 0; j < NUM_COLS; ++j) {
				window.draw(DrawBrick(wall[i][j]));
			}
		}
		window.draw(DrawPaddle(paddle));
		window.draw(DrawBall(ball));
		// window.draw(...);

		// end the current frame
		window.display();
	}
	if (window.isOpen()) {
		Font comicSans;
		comicSans.loadFromFile("COMICBD.TTF");
		window.clear(Color::White);
		Text text;
		text.setFont(comicSans);
		text.setString("YOU'RE A LOSER");
		text.setCharacterSize(90);
		text.setFillColor(Color::Red);
		text.setStyle(Text::Bold);
		window.draw(text);
		window.display();
	}
	
	system("pause");
	return EXIT_SUCCESS;
}

RectangleShape DrawBrick(Brick brick) {
	RectangleShape rectangle;
	if (brick.getBreakCounter() > 0) {
		rectangle.setPosition(Vector2f(brick.getLeftX(), brick.getTopY())); // places the brick
		rectangle.setSize(Vector2f(brick.getRightX()-brick.getLeftX(), brick.getBottomY()-brick.getTopY())); // defines the size of the brick
		//rectangle.setCornersRadius(5);
		rectangle.setOutlineColor(Color::Black);
		rectangle.setOutlineThickness(1);
		switch(brick.getBreakCounter()) {
		case 3:
			rectangle.setFillColor(Color::Green); // bricks are initially green
			break;
		case 2:
			rectangle.setFillColor(Color::Yellow); // after one hit they turn yellow
			break;
		case 1:
			rectangle.setFillColor(Color::Red); // after another hit they turn red
			break;
		};
	}
	return rectangle;
}

RectangleShape DrawPaddle(Paddle paddle) {
	RectangleShape rectangle;
	rectangle.setPosition(Vector2f(paddle.getLeftX(), paddle.getTopY())); // places the brick
	rectangle.setSize(Vector2f(PADDLE_WIDTH, PADDLE_HEIGHT)); // defines the size of the brick
	//rectangle.setCornersRadius(5);
	rectangle.setFillColor(Color::Blue);
	rectangle.setOutlineColor(Color::Black);
	rectangle.setOutlineThickness(1);
	return rectangle;
}

CircleShape DrawBall(Ball ball) {
	CircleShape circle;
	circle.setPosition(Vector2f(ball.getXPos(), ball.getYPos()));
	circle.setRadius(ball.getRadius());
	circle.setFillColor(Color::Cyan);
	circle.setOutlineColor(Color::Black);
	circle.setOutlineThickness(1);
	return circle;
}

void CheckIfBrokenX(Ball ball, Brick wall[NUM_ROWS][NUM_COLS]) {
	for (i = 0; i < NUM_ROWS; ++i) {
		for (j = 0; j < NUM_COLS; ++j) {
			if ((fabs(ball.getXPos() - wall[i][j].getRightX()) < 1 // bounces ball off of left or right side of brick
				|| fabs(ball.getXPos() + 2 * ball.getRadius() - wall[i][j].getLeftX()) < 1)
				&& ball.getYPos() + 2 * ball.getRadius() > wall[i][j].getTopY()
				&& ball.getYPos() < wall[i][j].getBottomY()) {
				ball.xBounce();
				wall[i][j].BreakBrick();
				return;
			}
		}
	}
}